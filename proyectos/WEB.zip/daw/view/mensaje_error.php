<?php    
    require_once('view/cabecera.php');
?>
<main>
    <h1>NECESITAS INICIAR SESIÓN PARA ACCEDER</h1>
    <fieldset>
        <legend>SUNEGAMI</legend>
        <p>Registrate e inicia sesión, así podrás crear álbumnes que contengan tus fotos preferidas.</p>
    </fieldset>
</main>
    
<!--************************************************************************************-->
<?php    
    require_once('view/inicio.php');
    ?>
<!--************************************************************************************-->
<?php    
    require_once('view/pie.php');
?>
    