<?php
include "./controller/inicio.php";
include "./view/inicio.php";
?>