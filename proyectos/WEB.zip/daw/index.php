<?php


$request_uri = $_SERVER['REQUEST_URI'];

// Dividir la URI en partes
$url_parts = explode('?', $request_uri);

// Tomar la ruta de la URL (parte antes del '?')
$path = $url_parts[0];

switch ($path) {
    case '/':
        include ('view/index.php');
        break;
    case '/accesibilidad':
        include ('view/accesibilidad.php');
        break;
    case '/album':
        include ('view/album.php');
        break;
    case '/albumes':
        include ('view/albumes.php');
        break;
    case '/anyadirFoto':
        include ('view/anyadirFoto.php');
        break;
    case '/buscar':
        include ('view/buscar.php');
        break; 
    case '/configurar':
        include ('view/configurar.php');
        break; 
    case '/crear_album':
        include ('view/crear_album.php');
        break; 
    case '/datos':
        include ('view/datos.php');
        break;
    case '/detalle':
        include ('view/detalle.php');
        break;
    case '/errores':
        include ('view/errores.php');
        break;
    case '/fotos':
        include ('view/fotos.php');
        break;
    case '/inicio.php':
        include ('view/view/inicio.php');
        break; 
    case '/mensaje_error':
        include ('view/mensaje_error.php');
        break;
    case '/perfil':
        include ('view/perfil.php');
        break;
    case '/resultado':
        include ('view/resultado.php');
        break;
    case '/res_album':
        include ('view/res_album.php');
        break;
    case '/res_foto':
        include ('view/res_foto.php');
        break;
    case '/res_registro':
        include ('view/res_registro.php');
        break;
    case '/res_datos':
        include ('view/res_datos.php');
        break;
    case '/respuesta_solicitar_album':
        include ('view/respuesta_solicitar_album.php');
        break;  
    case '/solicitar_album':
        include ('view/solicitar_album.php');
        break; 
    
    default:
        header('HTTP/1.0 404 Not Found');
        echo <<<hereDoc
        <head>
        <link rel="stylesheet" href="estilo.css" media="screen" title="Modo principal">
        </head>
        <aside id=pag_error>
        <fieldset >
        <legend class="error_pag">PELIGRO!!</legend>
        <p>Página no encontrada</p>
        </fieldset>
        </aside>
     
        hereDoc;

        break;
}
?>